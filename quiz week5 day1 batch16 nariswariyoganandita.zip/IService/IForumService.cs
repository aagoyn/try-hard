﻿using LearningManagement.Model;

namespace LearningManagement.IService;

public interface IForumService
{
    void CreateForum(Forum newForum);
    bool IsForumAvailableForSession(int sessionId);
    List<ForumDtl> GetForumDetails(int ForumId);
}
