﻿using LearningManagement.Model;

namespace LearningManagement.IService;

public interface IClassService
{
    int AddClass(Class newClass, int CreatedBy, int LecturerId);
    void AssignLecturerToClass(int lecturerId, int classId);
    List<Class> GetClassesAssignedToLecturer(int lecturerId);
    Class GetClassById(int classId);


}
