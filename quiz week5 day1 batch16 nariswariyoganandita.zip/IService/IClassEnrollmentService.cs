﻿using LearningManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.IService
{
    public interface IClassEnrollmentService
    {
        int EnrollStudent(int classId, int studentId, int CreatedBy);
        List<Class> GetUnenrolledClasses(int studentId);
        List<Class> GetEnrolledClasses(int studentId);
    }
}
