﻿namespace LearningManagement.IService
{
    public interface IAssignmentService
    {
        //int AddAssignment(Assignment newAssignment);
        bool IsAssignmentAvailableForSession(int sessionId);
    }
}
