﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class ClassEnrollment : BaseModel
    {
        public Class ClassId { get; set; }
        public User StudentId { get; set; }
    }
}
