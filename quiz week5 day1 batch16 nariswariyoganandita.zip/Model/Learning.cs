﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class Learning : BaseModel
    {
        public string DayName { get; set; }
        public DateOnly LearningDate { get; set; }
        public Class ClassId { get; set; }
    }
}
