﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class QuestionFile
    {
        public Question QuestionId { get; set; }
        public FileLms FileContent { get; set; }
    }
}
