﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class Forum
    {
        public string ForumTitle { get; set; }
        public string ForumContent { get; set; }
        public Session SessionId { get; set; }
        public User LecturerId { get; set; }
    }
}
