﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class SubmissionDtlFile
    {
        public SubmissionDtl SubmissionDtlId { get; set; }
        public FileLms SubmissionFile { get; set; }
    }
}
