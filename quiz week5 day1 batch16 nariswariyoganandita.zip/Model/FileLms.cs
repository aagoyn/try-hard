﻿namespace LearningManagement.Model;

public class FileLms : BaseModel
{
    public string FileTitle { get; set; }
    public string FileExtension { get; set; }
}
