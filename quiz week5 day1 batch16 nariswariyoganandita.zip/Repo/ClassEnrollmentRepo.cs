﻿using LearningManagement.DBConnection;
using LearningManagement.IRepo;
using LearningManagement.Model;
using Npgsql;

namespace LearningManagement.Repo
{
    public class ClassEnrollmentRepo : IClassEnrollmentRepo
    {
        public int EnrollStudent(int classId, int studentId, int CreatedBy)
        {
            const string query = "INSERT INTO t_class_enrollment (class_id, student_id, created_by, created_at, ver, is_active) " +
                "VALUES (@classId, @studentId, @CreatedBy, NOW(), 1, TRUE) RETURNING id";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@classId", classId);
                    command.Parameters.AddWithValue("@studentId", studentId);
                    command.Parameters.AddWithValue("@CreatedBy", CreatedBy);

                    object result = command.ExecuteScalar();

                    if (result != null && int.TryParse(result.ToString(), out int enrollmentId))
                    {
                        return enrollmentId;
                    }
                }
            }

            return -1;
        }

        public List<Class> GetUnenrolledClasses(int studentId)
        {
            List<Class> enrolledClasses = GetEnrolledClasses(studentId); //ec

            List<Class> allClasses = GetAllClasses(); //c

            List<Class> unenrolledClasses = allClasses.Where(c => !enrolledClasses.Any(ec => ec.Id == c.Id)).ToList();

            return unenrolledClasses;
        }

        public List<Class> GetEnrolledClasses(int studentId)
        {
            List<Class> enrolledClasses = new List<Class>();

            const string query = "SELECT c.* FROM t_class c " +
                                 "JOIN t_class_enrollment ce ON c.id = ce.class_id " +
                                 "WHERE ce.student_id = @studentId";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@studentId", studentId);

                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Class classItem = new Class()
                            {
                                Id = (int)reader["id"],
                                ClassCode = (string)reader["class_code"],
                                ClassName = (string)reader["class_name"],
                                ClassDesc = (string)reader["class_desc"],
                            };

                            enrolledClasses.Add(classItem);
                        }
                    }
                }
            }

            return enrolledClasses;
        }

        public List<Class> GetAllClasses()
        {
            List<Class> availableClasses = new List<Class>();
            const string query = "SELECT * FROM t_class";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Class classItem = new Class()
                            {
                                Id = (int)reader["id"],
                                ClassCode = (string)reader["class_code"],
                                ClassName = (string)reader["class_name"],
                                ClassDesc = (string)reader["class_desc"],
                            };

                            availableClasses.Add(classItem);
                        }
                    }
                }
            }

            return availableClasses;
        }
    }
}
