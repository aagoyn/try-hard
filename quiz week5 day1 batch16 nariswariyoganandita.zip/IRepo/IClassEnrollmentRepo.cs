﻿using LearningManagement.Model;

namespace LearningManagement.IRepo;

public interface IClassEnrollmentRepo
{
    int EnrollStudent(int classId, int studentId, int CreatedBy);
    List<Class> GetUnenrolledClasses(int studentId);

    List<Class> GetEnrolledClasses(int studentId);
}
