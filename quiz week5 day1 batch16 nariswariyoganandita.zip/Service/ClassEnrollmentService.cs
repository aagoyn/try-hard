﻿using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Model;

namespace LearningManagement.Service;

public class ClassEnrollmentService : IClassEnrollmentService
{
    private readonly IClassEnrollmentRepo classEnrollmentRepo;

    public ClassEnrollmentService(IClassEnrollmentRepo classEnrollmentRepo)
    {
        this.classEnrollmentRepo = classEnrollmentRepo;
    }
    public int EnrollStudent(int classId, int studentId, int CreatedBy)
    {
        return classEnrollmentRepo.EnrollStudent(classId, studentId, CreatedBy);
    }

    public List<Class> GetUnenrolledClasses(int studentId)
    {
        return classEnrollmentRepo.GetUnenrolledClasses(studentId);
    }

    public List<Class> GetEnrolledClasses(int studentId)
    {
        return classEnrollmentRepo.GetEnrolledClasses(studentId);
    }
}
