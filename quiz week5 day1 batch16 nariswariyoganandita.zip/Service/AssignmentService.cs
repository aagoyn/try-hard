﻿using LearningManagement.IRepo;
using LearningManagement.IService;
namespace LearningManagement.Service;

public class AssignmentService : IAssignmentService
{
    private readonly IAssignmentRepo assignmentRepo;

    public AssignmentService(IAssignmentRepo assignmentRepo)
    {
        this.assignmentRepo = assignmentRepo;
    }

    public bool IsAssignmentAvailableForSession(int sessionId)
    {
        return assignmentRepo.IsAssignmentAvailableForSession(sessionId);
    }

    //public int AddAssignment(Assignment newAssignment)
    //{
    //    return assignmentRepo.AddAssignment(newAssignment);
    //}
}
