﻿using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Service
{
    public class ForumService : IForumService
    {
        private readonly IForumRepo forumRepo;

        public ForumService(IForumRepo forumRepo)
        {
            this.forumRepo = forumRepo;
        }
        public void CreateForum(Forum newForum)
        {
            forumRepo.CreateForum(newForum);
        }
        public bool IsForumAvailableForSession(int sessionId)
        {
            return forumRepo.IsForumAvailableForSession(sessionId);
        }
        public List<ForumDtl> GetForumDetails(int ForumId)
        {
            return forumRepo.GetForumDetails(ForumId);
        }
    }
}
