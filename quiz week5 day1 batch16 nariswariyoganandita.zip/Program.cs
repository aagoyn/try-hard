﻿using LearningManagement.DBConnection;
using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Repo;
using LearningManagement.Service;
using LearningManagement.View;
using Npgsql;
namespace LearningManagement
{
    class Program
    {
        static void Main()
        {
            string connectionString = ConnectionDB.ConnectionString;

            // Initialize repositories
            IUserRepo userRepo = new UserRepo();
            IClassRepo classRepo = new ClassRepo();
            IFileRepo fileRepo = new FileRepo();
            ILearningRepo learningRepo = new LearningRepo();
            ISessionRepo sessionRepo = new SessionRepo();
            IMaterialRepo materialRepo = new MaterialRepo();
            IMaterialDtlRepo materialDtlRepo = new MaterialDtlRepo();
            IClassEnrollmentRepo classEnrollmentRepo = new ClassEnrollmentRepo();
            IAssignmentRepo assignmentRepo = new AssignmentRepo();
            IForumRepo forumRepo = new ForumRepo();

            // Initialize services
            ILoginService loginService = new LoginService(userRepo);
            IUserService userService = new UserService(userRepo);
            IClassService classService = new ClassService(classRepo);
            IFileService fileService = new FileService(fileRepo);
            ILearningService learningService = new LearningService(learningRepo);
            ISessionService sessionService = new SessionService(sessionRepo);
            IMaterialService materialService = new MaterialService(materialRepo);
            IMaterialDtlService materialDtlService = new MaterialDtlService(materialDtlRepo);
            IClassEnrollmentService classEnrollmentService = new ClassEnrollmentService(classEnrollmentRepo);
            IAssignmentService assignmentService = new AssignmentService(assignmentRepo);
            IForumService forumService = new ForumService(forumRepo);

            MainView mainView = new MainView(loginService, userService, classService, fileService, learningService,
                                            sessionService, materialService, materialDtlService, classEnrollmentService,
                                            assignmentService, forumService);
            mainView.Welcome();
        }

    }
}
