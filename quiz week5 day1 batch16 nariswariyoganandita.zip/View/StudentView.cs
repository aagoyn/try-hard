﻿using LearningManagement.IService;
using LearningManagement.Model;
using LearningManagement.Service;

namespace LearningManagement.View
{
    class StudentView
    {
        private readonly ILoginService loginService;
        private readonly IUserService userService;
        private readonly IClassService classService;
        private readonly IFileService fileService;
        private readonly ILearningService learningService;
        private readonly ISessionService sessionService;
        private readonly IMaterialService materialService;
        private readonly IMaterialDtlService materialDtlService;
        private readonly IClassEnrollmentService classEnrollmentService;
        private readonly IAssignmentService assignmentService;
        private readonly IForumService forumService;

        private User loggedInUser;

        public StudentView(ILoginService loginService, User loggedInUser, IUserService userService,
                        IClassService classService, IFileService fileService, ILearningService learningService,
                        ISessionService sessionService, IMaterialService materialService, IMaterialDtlService materialDtlService,
                        IClassEnrollmentService classEnrollmentService, IAssignmentService assignmentService, IForumService forumService)
        {
            this.loginService = loginService;
            this.loggedInUser = loggedInUser;
            this.userService = userService;
            this.classService = classService;
            this.fileService = fileService;
            this.learningService = learningService;
            this.sessionService = sessionService;
            this.materialService = materialService;
            this.materialDtlService = materialDtlService;
            this.classEnrollmentService = classEnrollmentService;
            this.assignmentService = assignmentService;
            this.forumService = forumService;
        }
        public void StudentMenu(User loggedInUser)
        {
            this.loggedInUser = loggedInUser;

            bool isRunning = true;
            while (isRunning)
            {
                Console.WriteLine($"-{loggedInUser.Id}-");
                Console.WriteLine("\n--- Student Menu ---\n");
                Console.WriteLine("1. Enroll To Class");
                Console.WriteLine("2. Show Learning");
                Console.WriteLine("3. Show Enrolled Classes");
                Console.WriteLine("4. Switch User");
                Console.Write("Choose Option: ");

                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        EnrollClass();
                        break;
                    case "2":
                        //ShowLearning();
                        break;
                    case "3":
                        ShowEnrolledClasses();
                        break;
                    case "4":
                        isRunning = false;
                        MainView mainView = new MainView(loginService, userService, classService, fileService, learningService,
                                                        sessionService, materialService, materialDtlService, classEnrollmentService, assignmentService, forumService);
                        mainView.Login();
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
            }
        }

        public void EnrollClass()
        {
            this.loggedInUser = loggedInUser;

            do
            {
                Console.WriteLine("--- Enroll to Class ---");

                List<Class> availableClasses = classEnrollmentService.GetUnenrolledClasses(loggedInUser.Id);
                if (availableClasses.Count > 0)
                {
                    Console.WriteLine("Available Classes:");
                    for (int i = 0; i < availableClasses.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {availableClasses[i].ClassCode} - {availableClasses[i].ClassName}");
                    }

                    Console.Write("Choose a Class to Enroll : ");
                    if (int.TryParse(Console.ReadLine(), out int selectedClassIndex) && selectedClassIndex >= 1 && selectedClassIndex <= availableClasses.Count)
                    {
                        Class selectedClass = availableClasses[selectedClassIndex - 1];

                        int CreatedBy = loggedInUser.Id;
                        int enrollmentId = classEnrollmentService.EnrollStudent(selectedClass.Id, loggedInUser.Id, CreatedBy);

                        if (enrollmentId > 0)
                        {
                            Console.WriteLine($"Hallo, {loggedInUser.Fullname}. You have successfully enrolled in class: [{selectedClass.ClassCode} - {selectedClass.ClassName}]");

                            Console.Write("Do you want to enroll in another class? (y/n): ");
                            string response = Console.ReadLine();
                            if (response == "n")
                            {
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Enrollment failed. Please try again.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Enrollment canceled.");
                    }
                }
                else
                {
                    Console.WriteLine("No available classes for enrollment.");
                }
            } while (true);
        }

        //public void ShowEnrolledClasses()
        //{
        //    Console.WriteLine($"\n{loggedInUser.Fullname} enrolled classes\n");

        //    List<Class> enrolledClasses = classEnrollmentService.GetEnrolledClasses(loggedInUser.Id);

        //    if (enrolledClasses != null && enrolledClasses.Count > 0)
        //    {
        //        int classNumber = 1;
        //        foreach (var enrolledClass in enrolledClasses)
        //        {
        //            Console.WriteLine($"{classNumber}. {enrolledClass.ClassCode} - {enrolledClass.ClassName}");
        //            classNumber++;
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("No enrolled classes found.");
        //    }
        //}

        //public void ShowLearning()
        //{
        //    List<Class> enrolledClasses = classEnrollmentService.GetEnrolledClasses(loggedInUser.Id);

        //    if (enrolledClasses != null && enrolledClasses.Count > 0)
        //    {
        //        Console.WriteLine($"\nLearning items for Classes enrolled by {loggedInUser.Fullname}:\n");

        //        foreach (var enrolledClass in enrolledClasses)
        //        {
        //            ShowLearningByClass(enrolledClass.Id);
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine($"No enrolled classes found for {loggedInUser.Fullname}.");
        //    }
        //}

        //public void ShowLearningByClass(int classId)
        //{
        //    Class selectedClass = classService.GetClassById(classId);

        //    if (selectedClass != null)
        //    {
        //        Console.WriteLine($" - Learning items for Class: {selectedClass.ClassName} ({selectedClass.ClassCode})");

        //        List<Learning> learnings = learningService.GetLearningByClass(classId);

        //        if (learnings != null && learnings.Count > 0)
        //        {
        //            int learningNumber = 1;
        //            foreach (var learning in learnings)
        //            {
        //                Console.WriteLine($"{learningNumber}. Day: {learning.DayName} - Learning Date: {learning.LearningDate.ToShortDateString()}");
        //                learningNumber++;
        //            }
        //        }
        //        else
        //        {
        //            Console.WriteLine("\tNo learning items found for this class.\n");
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("Class not found.");
        //    }
        //}
        public void ShowEnrolledClasses()
        {
            Console.WriteLine($"\n{loggedInUser.Fullname} enrolled classes\n");

            List<Class> enrolledClasses = classEnrollmentService.GetEnrolledClasses(loggedInUser.Id);

            if (enrolledClasses != null && enrolledClasses.Count > 0)
            {
                int classNumber = 1;
                foreach (var enrolledClass in enrolledClasses)
                {
                    Console.WriteLine($"{classNumber}. {enrolledClass.ClassCode} - {enrolledClass.ClassName}");
                    classNumber++;
                }

                Console.Write("Choose a Class to view Learning items: ");
                if (int.TryParse(Console.ReadLine(), out int selectedClassIndex) && selectedClassIndex >= 1 && selectedClassIndex <= enrolledClasses.Count)
                {
                    Class selectedClass = enrolledClasses[selectedClassIndex - 1];

                    ShowLearningByClass(selectedClass.Id);
                }
                else
                {
                    Console.WriteLine("Invalid input. Returning to the main menu.");
                }
            }
            else
            {
                Console.WriteLine("No enrolled classes found.");
            }
        }

        public void ShowLearningByClass(int classId)
        {
            Class selectedClass = classService.GetClassById(classId);

            if (selectedClass != null)
            {
                Console.WriteLine($"\n- Learning items for Class: {selectedClass.ClassName} ({selectedClass.ClassCode})");

                List<Learning> learnings = learningService.GetLearningByClass(classId);

                if (learnings != null && learnings.Count > 0)
                {
                    int learningNumber = 1;
                    foreach (var learning in learnings)
                    {
                        Console.WriteLine($"{learningNumber}. Day: {learning.DayName} - Learning Date: {learning.LearningDate.ToShortDateString()}");
                        learningNumber++;
                    }

                    Console.Write("Choose a Learning item to view Sessions: ");
                    if (int.TryParse(Console.ReadLine(), out int selectedLearningIndex) && selectedLearningIndex >= 1 && selectedLearningIndex <= learnings.Count)
                    {
                        Learning selectedLearning = learnings[selectedLearningIndex - 1];

                        ShowSessions(selectedLearning.Id);
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Returning to the main menu.");
                    }
                }
                else
                {
                    Console.WriteLine("\tNo learning items found for this class.\n");
                }
            }
            else
            {
                Console.WriteLine("Class not found.");
            }
        }

        //public void ShowSessions(int learningId)
        //{
        //    List<Session> sessions = sessionService.GetSessionsByLearning(learningId);

        //    if (sessions != null && sessions.Count > 0)
        //    {
        //        Console.WriteLine($" - Sessions for the selected Learning item:");

        //        int sessionNumber = 1;
        //        foreach (var session in sessions)
        //        {
        //            Console.WriteLine($"{sessionNumber}. [{session.Id}] - Session Title: {session.SessionTitle} | Start: {session.SessionStart} - End: {session.SessionEnd}");
        //            sessionNumber++;
        //        }

        //        Console.Write("Choose a Session option: ");
        //        int sessionOption;
        //        if (int.TryParse(Console.ReadLine(), out sessionOption))
        //        {
        //            switch (sessionOption)
        //            {
        //                case 1:
        //                    // Add your logic for Session Option 1
        //                    break;
        //                case 2:
        //                    // Add your logic for Session Option 2
        //                    break;
        //                // Add more cases for additional options as needed
        //                default:
        //                    Console.WriteLine("Invalid Session option. Returning to the main menu.");
        //                    break;
        //            }
        //        }
        //        else
        //        {
        //            Console.WriteLine("Invalid input. Returning to the main menu.");
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("\tNo sessions found for the selected Learning item.\n");
        //    }
        //}

        // Helper methods to check availability of forum, assignment, and material
        private bool IsForumAvailable(int sessionId)
        {
            // Check if forum is available for the given session
            return forumService.IsForumAvailableForSession(sessionId);
            //return true;
        }

        private bool IsAssignmentAvailable(int sessionId)
        {
            // Check if assignment is available for the given session
            return assignmentService.IsAssignmentAvailableForSession(sessionId);
            //return true;
        }

        private bool IsMaterialAvailable(int sessionId)
        {
            // Check if material is available for the given session
            return materialService.IsMaterialAvailableForSession(sessionId);
            //return true;
        }

        public void ShowSessions(int learningId)
        {
            List<Session> sessions = sessionService.GetSessionsByLearning(learningId);

            if (sessions != null && sessions.Count > 0)
            {
                Console.WriteLine($" - Sessions for the selected Learning item:");

                int sessionNumber = 1;
                foreach (var session in sessions)
                {
                    Console.WriteLine($"{sessionNumber}. [{session.Id}] - Session Title: {session.SessionTitle} | Start: {session.SessionStart} - End: {session.SessionEnd}");
                    sessionNumber++;
                }

                Console.Write("Choose a Session (or 0 to go back): ");
                int sessionOption;
                if (int.TryParse(Console.ReadLine(), out sessionOption))
                {
                    if (sessionOption == 0)
                    {
                        return;
                    }

                    if (sessionOption > 0 && sessionOption <= sessions.Count)
                    {
                        // Valid session option
                        var selectedSession = sessions[sessionOption - 1];

                        Console.WriteLine($"You selected Session [{selectedSession.Id}] - {selectedSession.SessionTitle}");

                        if (IsForumAvailable(selectedSession.Id))
                        {
                            Console.WriteLine("1. View Forum");
                        }

                        if (IsAssignmentAvailable(selectedSession.Id))
                        {
                            Console.WriteLine("2. View Assignment");
                        }

                        if (IsMaterialAvailable(selectedSession.Id))
                        {
                            Console.WriteLine("3. View Material");
                        }

                        Console.Write("Choose an option: ");
                        int option;
                        if (int.TryParse(Console.ReadLine(), out option))
                        {
                            switch (option)
                            {
                                case 1:
                                    // Add your logic to view forum
                                    break;
                                case 2:
                                    // Add your logic to view assignment
                                    break;
                                case 3:
                                    // Add your logic to view material
                                    break;
                                default:
                                    Console.WriteLine("Invalid option. Returning to the main menu.");
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Returning to the main menu.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Session option. Returning to the main menu.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Returning to the main menu.");
                }
            }
            else
            {
                Console.WriteLine("\tNo sessions found for the selected Learning item.\n");
            }
        }

    }
}
