﻿namespace LearningManagement.View
{
    class StudentView
    {
        public void StudentMenu()
        {

        }
    }
}
