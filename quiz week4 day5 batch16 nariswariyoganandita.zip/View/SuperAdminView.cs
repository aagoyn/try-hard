﻿using LearningManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.View
{
    public class SuperAdminView
    {
        public void SuperAdminMenu()
        {
            bool isRunning = true;
            while (isRunning)
            {
                Console.WriteLine("\n---Menu Super Admin---\n");
                Console.WriteLine("1. Register Lecturer");
                Console.WriteLine("2. Add Class");
                Console.WriteLine("3. Assign Lecturer to Class");
                Console.WriteLine("4. Switch User");
                Console.Write("Choose Option: ");

                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        RegisterLecturer();
                        break;
                    case "2":
                        AddClass();
                        break;
                    case "3":
                        AssignLecturer();
                        break;
                    case "4":
                        isRunning = false;
                        MainView mainView = new MainView();
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
            }
        }

        void RegisterLecturer()
        {
            Console.WriteLine("--- Register Lecturer ---");

            Console.Write("Input Fullname: ");
            string fullName = Console.ReadLine();

            Console.Write("Input Email: ");
            string email = Console.ReadLine();

            Console.WriteLine($"Lecturer {fullName} with email [{email}] has been added!");
        }

        void AddClass()
        {
            Console.WriteLine("--- Add Class ---");

            Console.Write("Input Class Name: ");
            string className = Console.ReadLine();

            Console.Write("Input Class Code: ");
            string classCode = Console.ReadLine();

            Console.Write("Input Class Description: ");
            string classDesc = Console.ReadLine();

            //Console.Write("Input Image: ");
            //string classImage = Console.ReadLine();

            Console.WriteLine($"Class {className} with code {classCode} has been added!");
        }

        private void AssignLecturer()
        {
            bool continueAssigning = true;

            while (continueAssigning)
            {
                Console.WriteLine("\n--- Assign Lecturer to Class ---");

                Console.WriteLine("Available Lecturer:");
                Console.WriteLine("1. Pak Joko");
                Console.WriteLine("2. Pak Budi");
                Console.WriteLine("3. Bu Lia");
                Console.Write("Choose Lecturer: ");
                int lecturerChoice = int.Parse(Console.ReadLine());

                Console.Write("How many classes will be assigned to the lecturer?: ");
                int classes = int.Parse(Console.ReadLine());

                for (int i = 0; i < classes; i++)
                {
                    // Tampilkan daftar Customer
                    Console.WriteLine("Available Class:");
                    Console.WriteLine("1. Java Class");
                    Console.WriteLine("2. Python Class");
                    Console.WriteLine("3. C# Class");
                    Console.Write("Select a class to assign a lecturer to: ");
                    int classesChoice = int.Parse(Console.ReadLine());

                    Console.WriteLine($"Lecturer {lecturerChoice} has been assigned to class {classesChoice}.");
                }

                Console.WriteLine("Do you want to assign another lecturer? (y/n): ");
                string answer = Console.ReadLine();

                if (answer.ToLower() != "y")
                {
                    continueAssigning = false;
                }
            }
        }
    }
}
