﻿using LearningManagement.Model;
using LearningManagement.Service;

namespace LearningManagement.View
{
    public class MainView
    {
        private LoginService loginService;

        public MainView()
        {
            loginService = new LoginService();
        }

        public void Welcome()
        {
            Console.WriteLine("Welcome to LMS!\n");
            Console.WriteLine("Do You Have an Account? (y/n)");

            string response = Console.ReadLine();

            if (response.ToLower() == "n")
            {
                Console.WriteLine("Would you like to register an account? (y/n)");
                string registerResponse = Console.ReadLine();

                if (registerResponse.ToLower() == "y")
                {
                    Console.WriteLine("Account registered successfully. Please log in.\n");
                    Login();
                }
                else
                {
                    Console.WriteLine("Thank you for using LMS. Goodbye!");
                }
            }
            else if (response.ToLower() == "y")
            {
                Login();
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'y' or 'n'.");
                Welcome();
            }
        }

        public void Login()
        {
            Console.WriteLine("Login to LMS\n");

            while (true)
            {
                Console.Write("Enter email: ");
                string email = Console.ReadLine();
                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                User user = loginService.Login(email, password);

                if (user != null)
                {
                    Console.WriteLine("\nLogin successful. Welcome, " + user.Email + "!\n");

                    if (user.Email == "sa")
                    {
                        SuperAdminView superAdminView = new SuperAdminView();
                        superAdminView.SuperAdminMenu(); //user dalem kurungnya
                        break;
                    }
                    else if (user.Email == Constant.Role.Pengajar)
                    {
                        //LecturerView lecturerView = new LecturerView();
                        //lecturerView.LecturerMenu(user);
                        //break;
                    }
                    else if (user.Email == Constant.Role.Siswa)
                    {
                        StudentView studentView = new StudentView();
                        studentView.StudentMenu();
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid username or password. Please try again.");
                }
            }
        }
    }
}
