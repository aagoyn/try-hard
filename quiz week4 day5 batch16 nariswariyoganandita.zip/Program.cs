﻿using LearningManagement.View;
namespace LearningManagement
{
    class Program
    {
        static void Main()
        {
            MainView mainView = new MainView();
            mainView.Welcome();
        }
    }
}
