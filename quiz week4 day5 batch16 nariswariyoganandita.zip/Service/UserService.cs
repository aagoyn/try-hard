﻿using LearningManagement.Constant;
using LearningManagement.Model;


namespace LearningManagement.Service;


public class UserService
{
    private List<User> users;

    public UserService()
    {
        users = new List<User>
        {
            new User { Email = "pengajar", Password = "pengajar"},
            new User { Email = "siswa", Password = "siswa" },
            new User { Email = "sa", Password = "sa"},
        };
    }
}
