﻿using LearningManagement.Model;


namespace LearningManagement.Service;

public class LoginService
{
    private List<User> users;

    public LoginService()
    {
        users = new List<User>
        {
            new User { Email = "pengajar", Password = "pengajar"},
            new User { Email = "siswa", Password = "siswa" },
            new User { Email = "sa", Password = "sa"},
        };
    }


    public User Login(string email, string password)
    {
        foreach (User user in users)
        {
            if (user.Email == email && user.Password == password)
            {
                return user;
            }
        }

        return null;
    }
}
