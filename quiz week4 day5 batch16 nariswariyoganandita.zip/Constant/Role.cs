﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Constant
{
    public class Role
    {
        public const string Pengajar = "pengajar";
        public const string Siswa = "siswa";
        public const string SA = "superadmin";

    }
}
