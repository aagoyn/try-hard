﻿using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Service
{
    public class MaterialDtlService : IMaterialDtlService
    {
        private readonly IMaterialDtlRepo materialDtlRepo;

        public MaterialDtlService(IMaterialDtlRepo materialDtlRepo)
        {
            this.materialDtlRepo = materialDtlRepo;
        }
        public void AddMaterialDetails(MaterialDtl materialDtl, int createdBy)
        {
            materialDtlRepo.AddMaterialDetails(materialDtl, createdBy);
        }
    }
}
