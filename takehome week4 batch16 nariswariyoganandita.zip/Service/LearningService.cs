﻿using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Model;

namespace LearningManagement.Service
{
    public class LearningService : ILearningService
    {
        private readonly ILearningRepo learningRepo;

        public LearningService(ILearningRepo learningRepo)
        {
            this.learningRepo = learningRepo;
        }
        public void AddLearning(int classId, string day, DateTime learningDate, int CreatedBy)
        {
            learningRepo.AddLearning(classId, day, learningDate, CreatedBy);
        }
        public List<Learning> GetLearningByLecturer(int lecturerId)
        {
            return learningRepo.GetLearningByLecturer(lecturerId);
        }
    }
}
