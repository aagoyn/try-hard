﻿using LearningManagement.IRepo;
using LearningManagement.Model;
using LearningManagement.IService;


namespace LearningManagement.Service;

public class FileService : IFileService
{
    private readonly IFileRepo fileRepo;

    public FileService(IFileRepo fileRepo)
    {
        this.fileRepo = fileRepo;
    }

    public int CreateFile(FileLms file)
    {
        return fileRepo.CreateFile(file);
    }
}
