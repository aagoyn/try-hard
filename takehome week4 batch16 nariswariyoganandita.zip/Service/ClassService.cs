﻿using LearningManagement.IService;
using LearningManagement.IRepo;
using LearningManagement.Model;

namespace LearningManagement.Service
{
    public class ClassService : IClassService
    {
        private readonly IClassRepo classRepo;

        public ClassService(IClassRepo classRepo)
        {
            this.classRepo = classRepo;
        }

        public int AddClass(Class newClass, int CreatedBy, int LecturerId)
        {
            return classRepo.AddClass(newClass, CreatedBy, LecturerId);
        }

        public void AssignLecturerToClass(int lecturerId, int classId)
        {
            classRepo.AssignLecturerToClass(lecturerId, classId);
        }

        public List<Class> GetClassesAssignedToLecturer(int lecturerId)
        {
            return classRepo.GetClassesAssignedToLecturer(lecturerId);
        }
    }
}
