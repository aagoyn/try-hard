﻿using LearningManagement.IRepo;
using LearningManagement.IService;
using LearningManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Service
{
    public class SessionService : ISessionService
    {
        private readonly ISessionRepo sessionRepo;

        public SessionService(ISessionRepo sessionRepo)
        {
            this.sessionRepo = sessionRepo;
        }
        public int AddSession(Session newSession, int CreatedBy)
        {
            return sessionRepo.AddSession(newSession, CreatedBy);
        }

        public List<Session> GetSessionsByLecturer(int lecturerId)
        {
            return sessionRepo.GetSessionsByLecturer(lecturerId);
        }
    }
}
