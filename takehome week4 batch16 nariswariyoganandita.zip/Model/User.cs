﻿using LearningManagement.Model;
namespace LearningManagement.Model;

public class User : BaseModel
{
    public string Fullname { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public FileLms PhotoProfile { get; set; }
    public Role Role { get; set; }

}
