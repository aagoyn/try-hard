﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    internal class ForumDtl : BaseModel
    {
        public Forum ForumId { get; set; }
        public string ForumContent { get; set; }
        public User UserId { get; set; }

    }
}
