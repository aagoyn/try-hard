﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class AssignmentDtl : BaseModel
    {
        public Question QuestionId { get; set; }
        public Assignment AssignmentId { get; set; }
    }
}
