﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class Class : BaseModel
    {
        public string ClassCode { get; set; }
        public string ClassName { get; set; }
        public string ClassDesc { get; set; }
        public FileLms Photo { get; set; }
        public User LecturerId { get; set; }
    }
}
