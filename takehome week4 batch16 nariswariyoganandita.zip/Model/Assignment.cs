﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Model
{
    public class Assignment : BaseModel
    {
        public string AssignmentTitle { get; set; }
        public int AssignmentDuration { get; set; }
        public Session SessionId { get; set; }
    }
}
