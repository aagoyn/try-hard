﻿using LearningManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.IService
{
    public interface ISessionService
    {
        int AddSession(Session newSession, int CreatedBy);
        List<Session> GetSessionsByLecturer(int lecturerId);
    }
}
