﻿using LearningManagement.DBConnection;
using LearningManagement.IRepo;
using LearningManagement.Model;
using Npgsql;
using System;

namespace LearningManagement.Repo
{
    public class ClassRepo : IClassRepo
    {
        public int AddClass(Class newClass, int CreatedBy, int selectedLecturerId)
        {
            const string query = "INSERT INTO t_class (class_name, class_code, class_desc, class_photo, lecturer_id, created_by, created_at, ver, is_active) " +
                                 "VALUES (@ClassName, @ClassCode, @ClassDesc, @ClassPhoto, @LecturerId, @CreatedBy, NOW(), 1, TRUE) RETURNING id";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ClassName", newClass.ClassName);
                    command.Parameters.AddWithValue("@ClassCode", newClass.ClassCode);
                    command.Parameters.AddWithValue("@ClassDesc", newClass.ClassDesc);
                    command.Parameters.AddWithValue("@ClassPhoto", newClass.Photo.Id);
                    command.Parameters.AddWithValue("@LecturerId", selectedLecturerId);
                    command.Parameters.AddWithValue("@CreatedBy", CreatedBy);

                    int newClassId = Convert.ToInt32(command.ExecuteScalar());
                    return newClassId;
                }
            }
        }

        public List<Class> GetAllClasses()
        {
            List<Class> classes = new List<Class>();
            const string query = "SELECT * FROM t_class";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Class classItem = new Class()
                            {
                                Id = (int)reader["id"],
                                ClassCode = (string)reader["class_code"],
                                ClassName = (string)reader["class_name"],
                                ClassDesc = (string)reader["class_desc"],
                                // Assuming you have properties for other columns, such as lecturer_id, created_by, created_at, etc.
                                //LecturerId = (int)reader["lecturer_id"],
                                //CreatedBy = (int)reader["created_by"],
                                //CreatedAt = (DateTime)reader["created_at"],
                                //UpdatedBy = reader["updated_by"] is DBNull ? (int?)null : (int)reader["updated_by"],
                                //UpdatedAt = reader["updated_at"] is DBNull ? (DateTime?)null : (DateTime)reader["updated_at"],
                                //Ver = (int)reader["ver"],
                                //IsActive = (bool)reader["is_active"]
                            };

                            classes.Add(classItem);
                        }
                    }
                }
            }

            return classes;
        }

        public List<Class> GetClassesAssignedToLecturer(int lecturerId)
        {
            List<Class> lecturerClasses = new List<Class>();
            const string query = "SELECT * FROM t_class WHERE lecturer_id = @LecturerId";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LecturerId", lecturerId);

                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Class classLecturer = new Class()
                            {
                                Id = (int)reader["id"],
                                ClassCode = (string)reader["class_code"],
                                ClassName = (string)reader["class_name"],
                                ClassDesc = (string)reader["class_desc"],
                                LecturerId = new User() { Id = (int)reader["lecturer_id"] },
                            };

                            lecturerClasses.Add(classLecturer);
                        }
                    }
                }
            }

            return lecturerClasses;
        }

        public void AssignLecturerToClass(int lecturerId, int classId)
        {
            const string query = "UPDATE t_class SET lecturer_id = @LecturerId WHERE id = @ClassId";

            using (NpgsqlConnection connection = new NpgsqlConnection(ConnectionDB.ConnectionString))
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LecturerId", lecturerId);
                    command.Parameters.AddWithValue("@ClassId", classId);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
