﻿using LearningManagement.Model;

namespace LearningManagement.IRepo;

public interface IClassRepo
{
    int AddClass(Class newClass, int createdBy, int LecturerId);
    void AssignLecturerToClass(int lecturerId, int classId);
    List<Class> GetClassesAssignedToLecturer(int lecturerId);
}
