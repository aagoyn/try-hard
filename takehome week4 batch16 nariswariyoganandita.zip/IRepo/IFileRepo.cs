﻿using LearningManagement.Model;

namespace LearningManagement.IRepo;

public interface IFileRepo
{
    int CreateFile(FileLms file);
}
