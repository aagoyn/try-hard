﻿using LearningManagement.DBConnection;
using LearningManagement.IService;
using LearningManagement.Model;
using LearningManagement.Constant;

using LearningManagement.Service;
using LearningManagement.View;
using Microsoft.VisualBasic;
using System.Reflection.Metadata.Ecma335;

namespace LearningManagement.View
{
    public class MainView
    {
        private readonly ILoginService loginService;
        private readonly IUserService userService;
        private readonly IClassService classService;
        private readonly IFileService fileService;
        private readonly ILearningService learningService;
        private readonly ISessionService sessionService;
        private readonly IMaterialService materialService;
        private readonly IMaterialDtlService materialDtlService;

        private User _user;
        private int _loggedInUserId;
        private User _loggedInUser;
        private User loggedInUser;

        public MainView(ILoginService loginService, IUserService userService, IClassService classService, IFileService fileService,
                        ILearningService learningService, ISessionService sessionService, IMaterialService materialService,
                        IMaterialDtlService materialDtlService)
        {
            this.loginService = loginService;
            this.userService = userService;
            this.classService = classService;
            this.fileService = fileService;
            this.learningService = learningService;
            this.sessionService = sessionService;
            this.materialService = materialService;

            _user = new User();
            _loggedInUser = new User();
            this.materialService = materialService;
            this.materialDtlService = materialDtlService;
        }
        public User LoggedInUser => _loggedInUser;
        public void Welcome()
        {
            Console.WriteLine("Welcome to LMS!\n");
            Console.Write("Do You Have an Account? (y/n): ");

            string response = Console.ReadLine();

            if (response.ToLower() == "n")
            {
                Console.Write("Would you like to register an account? (y/n): ");
                string registerResponse = Console.ReadLine();

                if (registerResponse.ToLower() == "y")
                {
                    int createdBy = _loggedInUser?.Id ?? 0;

                    RegisterView registerView = new RegisterView(userService, loginService, loggedInUser, classService, fileService, learningService, sessionService, materialService, materialDtlService);
                    registerView.RegisterStudent(createdBy);
                }
                else
                {
                    Console.WriteLine("Thank you for using LMS. Goodbye!");
                }
            }
            else if (response.ToLower() == "y")
            {
                Login();
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'y' or 'n'.");
                Welcome();
            }
        }

        public void Login()
        {
            Console.WriteLine("-- Log In to Learning Management System...");

            bool isLoginSuccessful = false;
            while (!isLoginSuccessful)
            {
                Console.WriteLine("--- Welcome to Learning Management System ---");
                Console.Write("Enter email: ");
                string email = Console.ReadLine();
                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                _loggedInUser = loginService.Login(email, password);
                _user = _loggedInUser;

                if (_loggedInUser != null)
                {
                    _loggedInUserId = _loggedInUser.Id;

                    UserLogin(_loggedInUser);
                    isLoginSuccessful = true;
                }
                else
                {
                    Console.WriteLine("Login failed. Incorrect username or password.");
                    Login();
                }
            }
        }

        private void UserLogin(User loggedInUser)
        {
            _loggedInUser = loggedInUser;

            switch (loggedInUser.Role.RoleCode)
            {
                case Constant.Role.SARoleCode:
                    Console.WriteLine($"Login as Super Admin successful.");
                    SuperAdminView superAdminView = new SuperAdminView(loginService, loggedInUser, userService, classService, fileService, learningService, sessionService, materialService, materialDtlService);
                    superAdminView.SuperAdminMenu(_user);
                    break;
                case Constant.Role.StudentRoleCode:
                    Console.WriteLine("Login as Student successful.");
                    StudentView studentView = new StudentView(loginService, loggedInUser);
                    studentView.StudentMenu(_user);
                    break;
                case Constant.Role.LecturerRoleCode:
                    Console.WriteLine("Login as Lecturer successful.");
                    LecturerView lecturerView = new LecturerView(loginService, loggedInUser, userService, classService, fileService, learningService, sessionService, materialService, materialDtlService);
                    lecturerView.LecturerMenu(_user);
                    break;
            }
        }
    }
}
