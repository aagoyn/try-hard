﻿using LearningManagement.IService;
using LearningManagement.Model;

namespace LearningManagement.View
{
    class StudentView
    {
        private readonly ILoginService loginService;


        private User loggedInUser;

        public StudentView(ILoginService loginService, User loggedInUser)
        {
            this.loggedInUser = loggedInUser;
        }
        public void StudentMenu(User loggedInUser)
        {
            Console.WriteLine("Hello Student");
        }
    }
}
