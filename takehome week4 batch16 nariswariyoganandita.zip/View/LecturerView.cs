﻿using LearningManagement.IService;
using LearningManagement.Model;
using LearningManagement.Service;


namespace LearningManagement.View
{
    class LecturerView
    {
        private readonly ILoginService loginService;
        private readonly IUserService userService;
        private readonly IClassService classService;
        private readonly IFileService fileService;
        private readonly ILearningService learningService;
        private readonly ISessionService sessionService;
        private readonly IMaterialService materialService;
        private readonly IMaterialDtlService materialDtlService;

        private User loggedInUser;

        public LecturerView(ILoginService loginService, User loggedInUser, IUserService userService,
                            IClassService classService, IFileService fileService, ILearningService learningService,
                            ISessionService sessionService, IMaterialService materialService, IMaterialDtlService materialDtlService)
        {
            this.loginService = loginService;
            this.loggedInUser = loggedInUser;
            this.userService = userService;
            this.classService = classService;
            this.fileService = fileService;
            this.learningService = learningService;
            this.sessionService = sessionService;
            this.materialService = materialService;
            this.materialDtlService = materialDtlService;
        }

        public void LecturerMenu(User loggedInUser)
        {
            this.loggedInUser = loggedInUser;

            bool isRunning = true;
            while (isRunning)
            {
                Console.WriteLine($"-{loggedInUser.Id}-");
                Console.WriteLine("\n--- Lecturer Menu ---\n");
                Console.WriteLine("1. Add Learning");
                Console.WriteLine("2. Add Session");
                Console.WriteLine("3. Add Material To Session");
                Console.WriteLine("4. Switch User");
                Console.Write("Choose Option: ");

                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        AddLearning();
                        break;
                    case "2":
                        AddSession();
                        break;
                    case "3":
                        AddMaterialToSession();
                        break;
                    case "4":
                        isRunning = false;
                        MainView mainView = new MainView(loginService, userService, classService, fileService, learningService, sessionService, materialService, materialDtlService);
                        mainView.Login();
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
            }
        }

        private void ShowClassesAssignedToLecturer(int lecturerId)
        {
            Console.WriteLine($"Classes assigned to {loggedInUser.Fullname}:");

            List<Class> lecturerClasses = classService.GetClassesAssignedToLecturer(lecturerId);

            if (lecturerClasses != null && lecturerClasses.Count > 0)
            {
                int classNumber = 1;
                foreach (var classLecturer in lecturerClasses)
                {
                    Console.WriteLine($"{classNumber}. [{classLecturer.ClassCode}] - {classLecturer.ClassName}");
                    classNumber++;
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("No classes assigned to you.");
            }
        }

        public void AddLearning()
        {
            Console.WriteLine("\n--- Add New Learning ---");

            ShowClassesAssignedToLecturer(loggedInUser.Id);

            Console.Write("Choose a class: ");
            if (int.TryParse(Console.ReadLine(), out int selectedClassIndex))
            {
                List<Class> lecturerClasses = classService.GetClassesAssignedToLecturer(loggedInUser.Id);

                if (selectedClassIndex > 0 && selectedClassIndex <= lecturerClasses.Count)
                {
                    Class selectedClass = lecturerClasses[selectedClassIndex - 1];

                    Console.WriteLine("Choose learning Day: ");
                    ChooseLearningDay();
                    Console.WriteLine("Choose a Day: ");

                    int CreatedBy = loggedInUser.Id;
                    if (int.TryParse(Console.ReadLine(), out int day) && day >= 1 && day <= 5)
                    {
                        string dayOfWeek = Enum.GetName(typeof(DayOfWeek), day);

                        Console.Write("Enter Learning Date (yyyy-MM-dd): ");
                        string dateString = Console.ReadLine();

                        if (DateTime.TryParse(dateString, out DateTime learningDate))
                        {
                            learningService.AddLearning(selectedClass.Id, dayOfWeek, learningDate, CreatedBy);

                            Console.WriteLine($"Learning in '{selectedClass.ClassName}' on {dayOfWeek} - {learningDate.ToShortDateString()} added successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Invalid date format. Learning not added.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid day. Learning not added.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid class selection. Learning not added.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Learning not added.");
            }
        }

        private void ChooseLearningDay()
        {
            Console.WriteLine("1. Monday");
            Console.WriteLine("2. Tuesday");
            Console.WriteLine("3. Wednesday");
            Console.WriteLine("4. Thursday");
            Console.WriteLine("5. Friday");
        }

        public Learning ShowLearningByLecturer(int lecturerId)
        {
            Console.WriteLine($"Learning items for lecturer {loggedInUser.Fullname}:");

            List<Learning> learnings = learningService.GetLearningByLecturer(lecturerId);

            if (learnings != null && learnings.Count > 0)
            {
                int learningNumber = 1;
                foreach (var learning in learnings)
                {
                    Console.WriteLine($"{learningNumber}. Day: {learning.DayName} - Learning Date: {learning.LearningDate.ToShortDateString()} - Class: {learning.ClassId.ClassName}");
                    learningNumber++;
                }

                Console.Write("Select a learning item (enter the number): ");
                if (int.TryParse(Console.ReadLine(), out int selectedLearningIndex))
                {
                    if (selectedLearningIndex > 0 && selectedLearningIndex <= learnings.Count)
                    {
                        return learnings[selectedLearningIndex - 1];
                    }
                }
            }
            else
            {
                Console.WriteLine("No learning items found for this lecturer.");
            }

            return null;
        }

        public void AddSession()
        {
            Console.WriteLine("\n--- Add New Session ---");

            Learning selectedLearning = ShowLearningByLecturer(loggedInUser.Id);

            if (selectedLearning != null)
            {
                Console.Write("Enter Session Title: ");
                string sessionTitle = Console.ReadLine();

                Console.Write("Enter Session Start (HH:mm): ");
                TimeSpan sessionStartTime = TimeSpan.Parse(Console.ReadLine());

                Console.Write("Enter Session End (HH:mm): ");
                TimeSpan sessionEndTime = TimeSpan.Parse(Console.ReadLine());

                // Create a Session object
                Session newSession = new Session
                {
                    LearningId = selectedLearning,
                    SessionTitle = sessionTitle,
                    SessionStart = sessionStartTime,
                    SessionEnd = sessionEndTime,
                };

                int CreatedBy = loggedInUser.Id;
                int newSessionId = sessionService.AddSession(newSession, CreatedBy);

                Console.WriteLine($"Session '{sessionTitle}' added to {selectedLearning.DayName}.");
            }
            else
            {
                Console.WriteLine("Invalid selection. Unable to add session.");
            }
        }

        public void ShowSessionByLecturer(int lecturerId)
        {
            Console.WriteLine($"Sessions for lecturer {loggedInUser.Fullname}:");

            List<Session> sessions = sessionService.GetSessionsByLecturer(lecturerId);

            if (sessions != null && sessions.Count > 0)
            {
                int sessionNumber = 1;
                foreach (var session in sessions)
                {
                    Console.WriteLine($"{sessionNumber}. [{session.Id}] - Day: {session.LearningId.DayName} - Session Title: {session.SessionTitle} | Start: {session.SessionStart} - End: {session.SessionEnd}");
                    sessionNumber++;
                }
            }
            else
            {
                Console.WriteLine("No sessions found for this lecturer.");
            }
        }


        public void AddMaterialToSession()
        {
            Console.WriteLine("\n--- Tambah Materi ke Sesi ---");

            // Tampilkan sesi yang tersedia
            List<Session> sessions = sessionService.GetSessionsByLecturer(loggedInUser.Id);
            if (sessions != null && sessions.Count > 0)
            {
                Console.WriteLine("Sesi yang Tersedia:");
                for (int i = 0; i < sessions.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. Pembelajaran: {sessions[i].LearningId.DayName} - Judul Sesi: {sessions[i].SessionTitle}");
                }

                // Pilih sesi
                Console.Write("Pilih sesi: ");
                if (int.TryParse(Console.ReadLine(), out int selectedSessionIndex) && selectedSessionIndex >= 1 && selectedSessionIndex <= sessions.Count)
                {
                    Session selectedSession = sessions[selectedSessionIndex - 1];

                    if (selectedSession != null && selectedSession.Id > 0)
                    {
                        // Kumpulkan informasi materi
                        Console.Write($"p- {selectedSession.Id} ");
                        Console.Write("Masukkan Judul Materi: ");
                        string materialTitle = Console.ReadLine();

                        Console.Write("Masukkan Konten Materi: ");
                        string materialContent = Console.ReadLine();

                        // Buat objek Material
                        Material newMaterial = new Material
                        {
                            MaterialTitle = materialTitle,
                            MaterialContent = materialContent,
                            SessionId = selectedSession,
                        };

                        // Tambahkan materi ke sesi

                        int CreatedBy = loggedInUser.Id;
                        int newMaterialId = materialService.AddMaterial(newMaterial, CreatedBy);

                        // Periksa apakah materi memiliki file
                        Console.Write("Apakah materi termasuk file? (y/n): ");
                        string response = Console.ReadLine();
                        if (response.Equals("y", StringComparison.OrdinalIgnoreCase))
                        {
                            // Kumpulkan detail file
                            Console.Write("Masukkan Judul File: ");
                            string fileTitle = Console.ReadLine();

                            Console.Write("Masukkan Ekstensi File: ");
                            string fileExtension = Console.ReadLine();

                            // Buat objek FileLms
                            FileLms materialFile = new FileLms
                            {
                                FileTitle = fileTitle,
                                FileExtension = fileExtension,
                                CreatedBy = loggedInUser.Id,
                                CreatedAt = DateTime.Now
                            };

                            // Tambah file ke database dan dapatkan ID file baru
                            int newFileId = fileService.CreateFile(materialFile);

                            // Buat objek MaterialDtl
                            MaterialDtl materialDtl = new MaterialDtl
                            {
                                MaterialId = new Material { Id = newMaterialId },
                                MaterialFile = new FileLms { Id = newFileId }
                            };

                            int createdBy = loggedInUser.Id;
                            materialDtlService.AddMaterialDetails(materialDtl, createdBy);

                            Console.WriteLine($"Materi '{materialTitle}' ditambahkan ke Sesi: {selectedSession.SessionTitle}.");
                        }
                        else
                        {
                            Console.WriteLine("Pilihan sesi tidak valid.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Tidak ada sesi yang ditemukan untuk dosen ini.");
                    }
                }


            }

        }
    }
}
