﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearningManagement.Constant
{
    public class Role
    {
        public const string SARoleCode = "ADM";
        public const string StudentRoleCode = "STD";
        public const string LecturerRoleCode = "LCT";
    }

    public class RoleId
    {
        public const int SARoleId = 1;
        public const int StudentRoleId = 2;
        public const int LecturerRoleId = 3;
    }
}
