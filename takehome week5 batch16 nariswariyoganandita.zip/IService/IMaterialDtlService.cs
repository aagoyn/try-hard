﻿using LearningManagement.Model;


namespace LearningManagement.IService
{
    public interface IMaterialDtlService
    {
        void AddMaterialDetails(MaterialDtl materialDtl);
    }
}
